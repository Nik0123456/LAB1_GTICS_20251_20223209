package org.example.l1_20223209;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class L120223209Application {

    public static void main(String[] args) {
        SpringApplication.run(L120223209Application.class, args);
    }

}
