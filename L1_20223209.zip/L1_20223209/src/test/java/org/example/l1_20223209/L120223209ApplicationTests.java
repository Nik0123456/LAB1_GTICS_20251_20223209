package org.example.l1_20223209;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L120223209ApplicationTests {

    @Test
    void contextLoads() {
    }

}
